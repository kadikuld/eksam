<?php
	// Get values from login.php file
	$username = $_POST['user'];
	$password = $_POST['pass'];

	// Prevent mysql injection
	$username = stripcslashes($username);
	$password = stripcslashes($password);
	$username = mysql_real_escape_string($username);
	$password = mysql_real_escape_string($password);

	//Connect to the server and select database
	mysql_connect("localhost", "root", "");
	mysql_select_db("login");

	$result = mysql_query("select * from users where username = '$username' and password = '$password'") 
	or die("Ei saanud andmebaasiga ühendust ".mysql_error());

	$row = mysql_fetch_array($result);
		if($row['username'] == $username && $row['password'] == $password) {
			echo "Sisselogimine õnnestus ".$row['username'];
		} else {
			echo "Sisselogimine ebaõnnestus";
		}
		
?>