<!DOCTYPE html>
<html>
<head>
		<title>Logi sisse</title>
		<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

	<div id="frm">
		<form action="process.php" method="POST">
			<p>
				<label>Kasutaja:</label>
				<input type="text" id="user" name="user"/>
			</p>
			<p>
				<label>Parool:</label>
				<input type="password" id="pass" name="pass"/>
			</p>
			<p>
				<input type="submit" id="btn" value="Logi sisse"/>
			</p>
		</form>
	</div>



</body>
</html>